# 动画叠加、切片与交互连续场景

先给动作一句表达目的，再组织对象和时间。下列方法复用现有配方；不要为每种组合新增Skill或时间轴引擎。完整作品仍按[整套设计指南](deck-design.md)先规划。

## 同一对象的多段动作

先把需要共同运动的文字、底板、图形组合，再给同一个组添加效果。原生界面的“添加动画”会追加，直接从动画库选另一个效果可能替换已有动画；COM使用`MainSequence.AddEffect`追加，精修既有效果继续用`polish_timing.ps1`按对象名和效果序号定位。

把动作写成短句，例如“出现 → 移动并略微放大 → 退出”：入口OnClick；路径与缩放WithPrevious，共用开始时刻和时长；出口另一个OnClick给讲述留停顿。需要同时旋转时，也由同一个点击组驱动。不要把两个不同终点的位移动画叠在同一个对象上。

WithPrevious的delay相对同一点击组安排；AfterPrevious会把起点放到前一动作之后。先明确锚点再填delay，避免每一层都多等一次。对同一对象追加后检查既有效果数量、入口/出口属性及中间画面，不能凭最后一条动画回读正常就判断整体正常。COM时长用秒，CLI时长用毫秒。

已有起点：[时间与路径](timing-patterns.md)、[书签整组循环](audio-bookmark-sequence.md)、[聚焦缩放](wheel-focus.md)。不要把点击组自动推广成循环或任意快速连击能力。

## 参数化斜切文字与刀光

1. 先完成标题字体、字号与位置，保留原始文字。复制两份并恢复相同Left/Top，避免默认复制偏移。
2. 用同一旋转矩形定义切线：一份文字Subtract得到上片，另一份Intersect得到下片。两片原位拼回完整字形。复用[真实字形布尔](glyph-slices.md)的可见Normal窗口、真实PrimaryShape与原生MergeShapes机制。
3. 微细同色描边可填平抗锯齿接缝；按实际显示检查，不能用厚描边掩盖错误的拼接。转曲片可编辑几何与颜色，改字仍需从原文字重建。
4. 在切线延长线上放窄菱形刀光，路径从画布外到另一侧画布外。刀光角度、轨迹斜率和切线共用同一角度参数；不要把斜率直接当成画布归一化的y位移。
5. 一个点击组中，刀光0秒启动、上片稍后、下片最后；两片沿切线方向移动不同距离，上片可再略微偏离切线以形成切口。先做一行再扩展多行，各行整体起点错开。

可用起始值：切线−10°，刀光/两片各0.5秒，上片delay0.25秒、下片0.4秒。这是起点，不是通用审美标准；按字重、切口位置和讲述节奏调整。切片、刀光及路径独立命名。新字体、角度、文字或多行要重新看接缝和动态。

## 固定导航 + 滚动时间轴 + 任务Zoom

先把整条时间轴、日期网格与任务放在同一个坐标世界。固定标题、行标签、季度导航独立。左侧遮罩置于滚动内容之上、固定文字之下；任务Zoom同样位于遮罩下方，避免滚到左边后盖住行标签或继续接收隐藏区域的点击。

复制页面作为季度状态，只对日期、任务及其Zoom应用同一个水平位移；固定层保持不动。对象名称/身份保持连续，状态之间用Morph。导航用指向真实目标SlideID的内部链接，不能以顺序Next代替随机季度跳转。OfficeCLI复制可能为共享名称补`!!`，后续COM应读取实际名称，不能假定与复制前字符串完全相同。

任务详情用真正Slide Zoom，启用Return to Zoom，保留目标关系、可用poster及正确层级。详情页完成后应返回**进入时的路线状态**，不是无条件跳到第一季度。缩略图可保持可见；若要换成透明poster，须另验命中区域、返回和背景，不由普通透明热点推导。需要章节范围返回时改用已有[Section Zoom](section-zoom.md)，不要把Slide Zoom改名。

不要假设真实Zoom缩略图能像普通形状一样被Morph连续移动。本次样稿曾出现任务已移动、缩略图仍在原处淡出的中间态；改用普通原生箭头随任务运动，透明自定义cover的真Zoom只承担落点处交互。沿已有hidden picture carrier方法替换Choice和Fallback图像，`zmPr.imageType=cover`防止被目标页preview替换；同时去掉缩略图边线。字段含义依据[微软Zoom属性](https://learn.microsoft.com/en-us/openspecs/office_standards/ms-pptx/059e3722-139d-4e41-9841-d53eecaf73f6)与[cover枚举](https://learn.microsoft.com/en-us/openspecs/office_standards/ms-pptx/9a710598-4590-41a1-9c0f-b34c63b9866d)。该选择只解决可见连续性，仍须实测透明区域能否点击和正常返回。

制作中至少实际操作一次前滚、后滚、详情进入/返回和重复进入，再看Morph期间的遮罩边界、标题稳定及Zoom是否跟随任务。任一单项配方通过不能代证这条链路。已有[导航与poster修复](interaction-patterns.md)、[连续状态](morph-patterns.md)和[悬停Zoom](hover-zoom-menu.md)可按需要复用。

## 精细路径与动画中心

路径使用画布归一化坐标：Δx/画布宽、Δy/画布高；起止应以对象中心计算。复制/改尺寸后先核起点和终点，必要时重算。转折需要连续切向时使用已有贝塞尔路径；动静节奏优先调整Timing加减速，不给所有对象再叠一条补偿路径。

绕边缘或任意铰链转动时，先用无填充/无线条辅助几何补足组包围盒，使组中心落在所需支点，再对整个组旋转。辅助几何参与包围盒，却不应遮挡或进入交互命中区。旋转前完成分组，之后不要再增删改变包围盒的成员。已验证起点是[笔记本铰链](laptop-hinge-scene.md)与[原生组件花瓣](native-components.md)；不默认移植PA插件的“形转路径”、时间序列面板或任意旋转中心接口。

## 3D翻页与Morph

原生组的透视旋转适合平面翻页；真实正反两面的立体卡片优先复用[双面GLB](glb-double-sided-card.md)。两者的对象类型与背面表现不同，按内容选，不混称。

平面翻页用“可见半页 + 对称辅助半页”把组中心放到书脊，再保持对象身份制作两个姿态，以Morph连接。先分组，再隐藏辅助半页；不要删除辅助半页而改变组包围盒。本机两页原创书本已实测：水平镜像辅助页Visible=0后Left/Width不变，Camera62、透视60°、RotationX0→180°、Contrasting灯光18、Morph2秒，原生Right→Left→Right及14个中间/结束帧通过。制作源在`examples/book-flip`，与既有铰链共用相机/组支点机制，没有新建3D引擎。

预留翻页中间态的空间：透视会把纸页投影放大，不能只按两张终态安排页眉与页脚。本例背面留白，内容在底层页面露出；不把旋转的背面当作已完成双面印刷文字。照片裁形、任意尺寸/相机、多张连续翻页或动态弯曲仍按实际作品另验，不扩大已有铰链或GLB的通过范围。

## 真孔遮罩 + 液面回弹 + 双层波浪

瓶形边界用全画布矩形减去真实瓶形，不以矩形窗口代替。复制同位置瓶形作为无填充描边层；减法遮罩使用`Fill.Background()`，液体在遮罩下，描边和静态文字在遮罩上。可复用[原生组件与背景窗口](native-components.md)的真孔/背景填充和[末段回弹](bounce-end.md)机制；追加前保留原配方边界。

基础液体可用矩形从下方Fly，先按2秒、末段回弹1.5秒（现有Intensity=0.75）制作，再看实际反弹幅度。进阶版改成两块独立的原生曲线波浪，由同一点击组沿不同斜线路径上升。路径按实际画布宽高归一化；不要把背景遮罩与液体一起移动。

波浪必须在**全程**覆盖瓶内横向范围，尤其初次露出瓶底时，左右边缘不能切进真孔。先确定波长，再增加周期和总宽度，避免仅拉宽导致波长意外改变。终态正确并不能证明中途没有矩形侧边。`examples/flask-wave`初版暴露竖边后，保持4cm波长、加宽至32cm，最终18秒原生实播与270个采样帧未见瓶外漏色；两层3秒斜线上升、基础Fly回弹及静态文字稳定已独立验证。

本例止于一次上升并保持，不推导无限循环、气泡、任意容积或自动百分比。改瓶形或路径后要检查空瓶、初次入孔、半程、波峰靠边和终态。曲线、遮罩、颜色与时间轴均可编辑，无需增加外部流体引擎。

## 三支烛焰的纵向错峰循环

只让烛焰运动，蜡烛、文字与背景保持静止。OfficeCLI建立可编辑外焰/内焰并组为三支独立目标，COM沿用Grow/Shrink与缓动机制：水平100%、纵向70%，单程0.2秒，自动反向，平滑开始/结束各0.1秒。三支使用WithPrevious，以0/0.1/0.2秒启动偏移形成错峰；持续循环至离页。不要同时缩小宽度，也不把透明GIF替代原生伸缩。

来源9Ewb0Rd3P3E 4:22:22–4:22:36。本地原始字幕已复读，Ego Lite将144p提高到1080p后核了六个实际画面：15747/15749/15751秒清晰显示70% Vertical、Smooth start/end各0.1sec、Auto-reverse；顶部显示Duration0.20，选中的第三支Delay0.20。前两支0/0.1秒是本样稿采用的错峰安排，不能冒称视频逐个展示过三个延迟数值。

```powershell
python scripts/flame_flicker_build.py --officecli EXE --out NEW_BASE.pptx
powershell -File scripts/flame_flicker_polish.ps1 -InputDeck NEW_BASE.pptx -OutputDeck NEW_FINAL.pptx -Officecli EXE
```

此hybrid组合复用既有Deck、原生Grow/AutoReverse和indefinite写入机制，不改变旧Grow配方。本机COM的`EffectParameters.Direction=17`对Grow报Invalid request；改设原生ScaleEffect的ByX/ToX=100、ByY/ToY=70。只改ByY而保留Size写入的ToX70会遗留横向收缩目标，必须核实实际`animScale`两组轴值，并在播放中确认宽度不变。完成COM保存关闭后再交给OfficeCLI追加repeat，避免双方同时编辑。

[两页原创烛焰与22秒实播](../../examples/flame-flicker/README.md)含静态对照。实际Right到静态页、Left返回，2键/0额外输入；606个编码帧按各自PTS测量，三支首次/返回均高56–80px、宽各自恒定36或37px，高度最低/最高比0.70且相位不同，静态页105帧完全不伸缩。18个分布画面已看，保存重开两页逐像素一致；包内三组真实矢量，无GIF/视频替代。只覆盖该三支原生组合与返回路线，不等同真实火焰模拟，也不据此升级GIF或指定触发媒体的组合结论。

## 可编辑组合样稿

仓库`examples/motion-combinations`提供斜切文字、同组五效果、季度状态/遮罩/Slide Zoom组合的制作示例。它是已有机制的组合小样，不是新的通用引擎。具体实播范围和限制见样稿README。

操作参考：[Kevin Stratvert动画](https://www.youtube.com/watch?v=3uJd-_JpG1w)07:05–08:24、15:45–24:45；[三种Zoom构图](https://www.youtube.com/watch?v=HvCcEMXKwpQ)01:45–03:11、06:30–08:11、09:19–10:11；[交互时间轴](https://www.youtube.com/watch?v=nNN3Ito_2Mw)09:54–11:23、13:49–17:16、17:33–21:16；[文字切片](https://www.youtube.com/watch?v=JPjXeJMDrc4)01:09–06:40；[触发器问答](https://www.youtube.com/watch?v=Mo5-Bu1SHGQ)02:43–05:33、06:49–08:32的对象命名与指定对象触发复用既有Pin/Kiosk机制；[书页翻转](https://www.youtube.com/watch?v=cwPaqUC1jT4)06:22–12:47，本例复核该段字幕与12张操作/效果帧后还原组支点、辅助页隐藏、60°透视、Contrasting光照及180°翻转，使用原创可编辑曲线纸面。

液面操作参考：[原生动画组合](https://www.youtube.com/watch?v=o12PIUTskS0)20:35–24:04。已复核该段实际操作帧和已有英文字幕：矩形Subtract瓶形、Slide background fill、Fly from bottom 2秒/末段Bounce1.5秒，以及双波浪斜线路径。3秒双波浪时长与具体位移为本例设计参数。
